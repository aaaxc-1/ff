<?php
return [
    'web' => array(
		'title' => '俗人云创付费进群系统',
		'oaname' => '俗人云创付费进群系统',              
		'softname' => '俗人云创付费进群系统',   
		'version' => '俗人云创付费进群系统',
		'copyright' => '俗人云创付费进群系统'
	),
	'page' => 20,
];