<?php
return [
	'onoff' => true, //表示关闭
    'ip' => "主域名", 
    'safe' => "分站域名",
    'authcode' => 'c'
];