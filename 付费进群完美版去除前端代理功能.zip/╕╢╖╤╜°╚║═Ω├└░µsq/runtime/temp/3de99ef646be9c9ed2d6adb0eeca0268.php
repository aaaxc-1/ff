<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:41:"template/substation/wxgrouptmp/index.html";i:1737382147;s:67:"/www/wwwroot/ffjq.yc88.us.kg/template/substation/common_header.html";i:1737382147;s:64:"/www/wwwroot/ffjq.yc88.us.kg/template/substation/common_top.html";i:1737382147;s:67:"/www/wwwroot/ffjq.yc88.us.kg/template/substation/common_footer.html";i:1737382147;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	  <meta charset="utf-8">
  <title><?php echo session("su_title"); ?> <?php echo $subweb['oaname']; ?></title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<link rel="stylesheet" href="/template/layuiadmin/layui/css/layui.css" media="all">
<link rel="stylesheet" href="/template/layuiadmin/style/admin.css" media="all">
<link href="/template/layuiadmin/layui/5.15.1/all.css" rel="stylesheet">
<script src="/template/layuiadmin/layui/2.0.6/clipboard.min.js"></script>
</head>
<body>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
      <div class="layui-col-md12">
        <div class="layui-card">
          <div class="layui-card-body">
              <div class="layui-box">
			<button class="layui-btn layuiadmin-btn-tags" data-type="add">添加(多图)</button>
			<?php if(!empty($webinfo['text2'])): ?><a class="layui-btn layuiadmin-btn-tags" href="<?php echo $webinfo['text2']; ?>" target="_blank">功能说明</a><?php endif; ?>
		    </div>
			<div class="layui-form" lay-filter="component-form-element">
            <div class="layui-box layui-laypage layui-laypage-molv"><?php echo $page; ?></div>
            <table class="layui-table" lay-even="" lay-skin="nob">
            <thead>
              <tr>
                <th width="35">序号</th>
                <th>状态</th>
                <th>群名称</th>
                <th>副标题</th>
                <th>群费用</th>
                <th width="120">管理</th>
              </tr> 
            </thead>
            <tbody>
             <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<tr id="tr_<?php echo $vo['wxgt_id']; ?>">
					<td class="text-center"><?php echo $vo['wxgt_id']; ?></td>
                    <td>
                    <?php if($vo['wxgt_status']==1): ?><span class="layui-badge layui-bg-blue">启用</span>
                    <?php elseif($vo['wxgt_status']==2): ?><span class="layui-badge layui-bg-black">禁用</span><?php endif; ?>
                    </td>
                    <td><span class="layui-badge-rim"><?php echo $vo['wxgt_title']; ?></span></td>
                    <td><span class="layui-badge-rim"><?php echo $vo['wxgt_subtitle']; ?></span></td>
                    <td><span class="layui-badge-rim"><?php echo $vo['wxgt_money']; ?> 元</span></td>
                    <td>
							<div class="layui-btn-group">
								<button class="layui-btn layui-btn-sm" onClick="calldel('<?php echo url('Wxgrouptmp/del',array('id'=>$vo['wxgt_id'])); ?>','tr_<?php echo $vo['wxgt_id']; ?>')"><i class="layui-icon">&#xe640;</i></button>
								<button class="layui-btn layui-btn-sm" data-type="edit" data-id="<?php echo $vo['wxgt_id']; ?>"><i class="layui-icon">&#xe642;</i></button>
							</div>
                    </td>
				</tr>
			<?php endforeach; endif; else: echo "" ;endif; ?>
            </tbody>
          </table> 
          <div class="layui-box layui-laypage layui-laypage-molv"><?php echo $page; ?></div>
		  </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="/template/layuiadmin/layui/layui.js"></script>
<script src="/template/group/index/js/jquery-1.11.1.min.js"></script>
<script src="/template/showjs.js"></script>
<script>
  layui.config({
    base: '/template/layuiadmin/' //静态资源所在路径
  }).extend({
    index: 'lib/index' //主入口模块
  }).use(['index','util','form', 'laydate','set','layer']);
</script> 
   <script>
	layui.use(['index','form'], function(){
		
		var form = layui.form;
		


    var $ = layui.$, active = {

	 
	  add: function(){
		var id = $(this).data('id');
		var url = '<?php echo url('wxgrouptmp/add'); ?>';
        layer.open({
          type: 2
          ,title: '添加多图模板'
          ,content: url
          ,area: ['800px', '750px']
        }); 
      },
      
      addimg: function(){
		var id = $(this).data('id');
		var url = '<?php echo url('wxgrouptmp/addimg'); ?>';
        layer.open({
          type: 2
          ,title: '添加单图模板'
          ,content: url
          ,area: ['800px', '750px']
        }); 
      },
      
      addgmb: function(){
		var id = $(this).data('id');
		var url = '<?php echo url('wxgrouptmp/addgmb'); ?>';
        layer.open({
          type: 2
          ,title: '添加官方模板'
          ,content: url
          ,area: ['800px', '750px']
        }); 
      },
      
      
	  edit: function(){
		var id = $(this).data('id');
		var url = '<?php echo url('wxgrouptmp/edit',array('id'=>'AAAAAA')); ?>';
		url = url.replace("AAAAAA",id)
        layer.open({
          type: 2
          ,title: '修改多图模板'
          ,content: url
          ,area: ['800px', '750px']
        }); 
      },
      
      editimg: function(){
		var id = $(this).data('id');
		var url = '<?php echo url('wxgrouptmp/editimg',array('id'=>'AAAAAA')); ?>';
		url = url.replace("AAAAAA",id)
        layer.open({
          type: 2
          ,title: '修改单图模板'
          ,content: url
          ,area: ['800px', '750px']
        }); 
      },
      
      editgmb: function(){
		var id = $(this).data('id');
		var url = '<?php echo url('wxgrouptmp/editgmb',array('id'=>'AAAAAA')); ?>';
		url = url.replace("AAAAAA",id)
        layer.open({
          type: 2
          ,title: '修改官方模板'
          ,content: url
          ,area: ['800px', '750px']
        }); 
      },
      
	 
	  

    } 
	
	 
    $('.layui-btn').on('click', function(){
      var type = $(this).data('type');
      active[type] ? active[type].call(this) : '';
    });

	
  });
  </script>
</body>
</html>