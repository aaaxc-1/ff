<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:35:"template/group/index/share_gmb.html";i:1739130516;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="target-densitydpi=device-dpi, width=device-width,height=device-height, initial-scale=1, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
    <meta name="format-detection" content="telephone=no" />
    <title>邀请你加入群聊</title>
    <link type="text/css" rel="stylesheet" href="/template/group/index/css.css"/>
    <link type="text/css" rel="stylesheet" href="/template/group/index/weui.min.css"/>
    <script src="/template/group/index/weui.min.js"></script>
    <script src="/template/layuiadmin/layui/3.6.0/jquery.min.js"></script>
    <script src="http://pv.sohu.com/cityjson?ie=utf-8"></script>
<style>
        body {
            background: #fff;
        }
        .warning {
            width: 80px;
            height: 80px;
            margin: 30px auto 15px;
        }
        .warning img {
            width: 85px;
            height: 85px;
        }
        .warntext {
            width: 80%;
            margin: 0 auto;
            text-align: center; 
            font-size: 20px;
            font-weight: bold;
        }
        
        /*简介模板 CSS*/
        /*这个用来挡住顶部的域名区域*/
        .header {
            position: fixed;
            top: 0;
            height: 100px;
            width: 100%;
            background: #fff;
        }
        .chatroom_member_list {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 10px;
            width: 90%;
            margin: 20px auto 0;
        }
        .chatroom_member_info {
            text-align: center;
            -webkit-tap-highlight-color:rgba(255,0,0,0);
        }
        .chatroom_member_info img {
            width: 50px;
            height: auto;
            border-radius: 10px;
        }
        .chatroom_member_info .chatroom_member_name {
            font-size: 14px;
            color: #b8b8b8;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
            word-break: break-all;
            width: 60px;
            text-align: center;
        }
        
        /*最多显示3行群简介*/
        .group_info_tip {
            text-overflow: -o-ellipsis-lastline;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            line-clamp: 3;
            -webkit-box-orient: vertical;
            font-size: 15px!important;
        }
        
        .addchatroombtn {
            width: 88%;
            padding: 12px 0;
            background: rgb(73, 194, 101);
            margin: 0 auto;
            position: fixed;
            left: 0;
            right: 0;
            bottom: 20px;
            border-radius: 12px;
            font-size: 16px;
            font-weight: bold;
            color: #fff;
            box-shadow: 0 4px 8px rgba(73, 194, 101);
            -webkit-tap-highlight-color:rgba(255,0,0,0);
        }
        .weui-half-screen-dialog__bd {
            padding-bottom: 56px
        }
        
        .weui-icon_msg.weui-icon-warn {
            min-width: 6.4em;
            min-height: 6.4em;
            margin-bottom: 24px;
            margin-top: 40px;
            margin-left: auto;
            margin-right: auto;
            -webkit-mask-image: url("data:image/svg+xml;charset=utf-8,%3Csvg width='24' height='24' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm0-1.2a8.8 8.8 0 100-17.6 8.8 8.8 0 000 17.6zm-.66-14.369h1.32l-.089 7.06H11.43l-.088-7.06zM12 17.073a.825.825 0 01-.835-.835.82.82 0 01.835-.835c.476 0 .835.36.835.835a.82.82 0 01-.835.835z' fill-rule='evenodd' fill-opacity='.9'/%3E%3C/svg%3E");
            color: var(--weui-YELLOW)
        }
        
        .weui-msg__desc {
            margin-bottom: 0
        }
        
        .weui-half-screen-dialog__attachment-area .weui-link {
            font-size: 14px
        }
        html {
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%
        }
        
        body {
            line-height: 1.6;
            font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
            font-size: 16px;
        }
        body,
        dd,
        dl,
        fieldset,
        h1,
        h2,
        h3,
        h4,
        h5,
        ol,
        p,
        textarea,
        ul {
            margin: 0
        }
        
        button,
        fieldset,
        input,
        legend,
        textarea {
            padding: 0
        }
        
        button,
        input,
        select,
        textarea {
            font-family: inherit;
            font-size: 100%;
            margin: 0;
            *font-family: Helvetica Neue, Helvetica, Arial, sans-serif
        }
        
        ol,
        ul {
            padding-left: 0;
            list-style-type: none
        }
        
        a img,
        fieldset {
            border: 0
        }
        
        a {
            text-decoration: none
        }
        
        * {
            -webkit-tap-highlight-color: rgba(0, 0, 0, .1)
        }
        
        html {
            font-size: 14px;
            text-align: center
        }
        
        body,
        html {
            height: 100%
        }
        
        body {
            background-color: var(--weui-BG-2);
            color: var(--weui-FG-0)
        }
        
        .body {
            display: -webkit-box;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            flex-direction: column;
            height: 100%;
            box-sizing: border-box;
            padding: -webkit-calc(48px + constant(safe-area-inset-top)) constant(safe-area-inset-right) constant(safe-area-inset-bottom) constant(safe-area-inset-left);
            padding: calc(48px + constant(safe-area-inset-top)) constant(safe-area-inset-right) constant(safe-area-inset-bottom) constant(safe-area-inset-left);
            padding: -webkit-calc(48px + env(safe-area-inset-top)) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left);
            padding: calc(48px + env(safe-area-inset-top)) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left)
        }
        
        @media screen and (max-height:640px) {
            .body {
                padding: -webkit-calc(32px + constant(safe-area-inset-top)) constant(safe-area-inset-right) constant(safe-area-inset-bottom) constant(safe-area-inset-left);
                padding: calc(32px + constant(safe-area-inset-top)) constant(safe-area-inset-right) constant(safe-area-inset-bottom) constant(safe-area-inset-left);
                padding: -webkit-calc(32px + env(safe-area-inset-top)) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left);
                padding: calc(32px + env(safe-area-inset-top)) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left)
            }
        }
        
        .body .container {
            -webkit-box-flex: 1;
            flex-grow: 1;
            overflow: hidden;
            flex-shrink: 1
        }
        
        .body .group_info {
            margin-left: 32px;
            margin-right: 32px;
            padding-bottom: 48px;
            position: relative;
            color: var(--weui-FG-1);
            font-size: 17px
        }
        
        @media screen and (max-height:640px) {
            .body .group_info {
                padding-bottom: 24px;
                margin-left: 32px;
                margin-right: 32px
            }
        }
        
        .body .msg {
            color: var(--weui-FG-1);
            font-size: 17px;
            text-align: center;
            margin-bottom: 8px
        }
        
        .body .group_name {
            margin-top: 24px;
            font-size: 22px;
            color: var(--weui-FG-0)
        }
        
        .body .group_icon {
            width: 64px;
            height: 64px;
            border-radius: 6px;
            display: block;
            margin: auto
        }
        
        .body .group_info.has-ext:after {
            content: " ";
            position: absolute;
            left: 0;
            bottom: 0;
            width: 100%;
            height: 1px;
            border-top: 1px solid var(--weui-FG-3);
            -webkit-transform-origin: 0 0;
            transform-origin: 0 0;
            -webkit-transform: scaleY(.5);
            transform: scaleY(.5)
        }
        
        .body .group_info_tip {
            color: var(--weui-FG-1);
            font-size: 17px;
            margin-top: 8px;
            text-align: center
        }
        
        .body .btn-area {
            position: relative;
            max-height: 168px;
            box-sizing: border-box;
            padding-bottom: 96px;
            padding-top: 100px
        }
        
        @media screen and (max-height:640px) {
            .body .btn-area {
                padding-bottom: 32px
            }
        }
        
        .body .btn-area:before {
            content: " ";
            height: 16px;
            position: absolute;
            top: -16px;
            width: 100%;
            left: 0;
            background: -webkit-gradient(linear, left top, left bottom, from(hsla(0, 0%, 100%, 0)), to(#fff));
            background: linear-gradient(180deg, hsla(0, 0%, 100%, 0), #fff)
        }
        
        @media (prefers-color-scheme:dark) {
            .body .btn-area:before {
                background: -webkit-gradient(linear, left top, left bottom, from(rgba(25, 25, 25, 0)), to(#191919));
                background: linear-gradient(180deg, rgba(25, 25, 25, 0), #191919)
            }
        }
        
        .body .container {
            position: relative
        }
        
        .body .container:before {
            z-index: 100;
            content: " ";
            height: 40px;
            position: absolute;
            top: 0;
            width: 100%;
            left: 0;
            background: linear-gradient(#fff, #fff 24px, hsla(0, 0%, 100%, 0) 40px)
        }
        
        @media (prefers-color-scheme:dark) {
            .body .container:before {
                background: linear-gradient(#191919, #191919 24px, rgba(25, 25, 25, 0) 40px)
            }
        }
        
        @media screen and (max-height:640px) {
            .body .container:before {
                height: 24px;
                background: linear-gradient(#fff, #fff 8px, hsla(0, 0%, 100%, 0) 24px)
            }
        }
        
        @media screen and (max-height:640px) and (prefers-color-scheme:dark) {
            .body .container:before {
                background: linear-gradient(#191919, #191919 8px, rgba(25, 25, 25, 0) 24px)
            }
        }
        
        .body .ext_info {
            counter-reset: section;
            text-align: left;
            padding: 40px 32px 55px;
            color: var(--weui-FG-1);
            word-break: break-all;
            font-size: 14px;
            overflow: scroll;
            box-sizing: border-box;
            height: 100%
        }
        
        @media screen and (max-height:640px) {
            .body .ext_info {
                padding: 24px 24px 0
            }
        }
        
        .body .ext_info a {
            color: var(--weui-LINK)
        }
        
        .body .ext_info p {
            word-break: break-word;
            position: relative;
            padding-left: 18px;
            line-height: 20px;
            margin-bottom: 16.8px
        }
        
        .body .ext_info em {
            position: absolute;
            left: 0;
            font-style: normal;
            display: inline-block;
            vertical-align: middle;
            width: 20px;
            height: 20px;
            -webkit-mask-image: url("data:image/svg+xml;charset=UTF-8,%3csvg width='20' height='20' xmlns='http://www.w3.org/2000/svg'%3e%3ccircle cx='10' cy='10' r='1.5' fill-rule='evenodd'/%3e%3c/svg%3e");
            background-color: currentColor
        }
        
        .body .being_invited {
            color: #21b100
        }
        
        .body .being_invited,
        .body .overseas {
            font-size: 18px;
            padding: 0 15px
        }
        
        .room_icon {
            height: 20px;
            width: 24px;
            position: relative;
            top: 3px;
            left: 8px
        }
        
        .page_msg {
            padding: 144px 32px 0;
            text-align: center
        }
        
        @media screen and (max-height:640px) {
            .page_msg {
                padding-top: 88px
            }
        }
        
        .page_msg .title {
            font-size: 22px;
            color: var(--weui-FG-0)
        }
        
        .page_msg .group_info {
            margin-top: 72px;
            position: relative;
            color: var(--weui-FG-1);
            font-size: 17px
        }
        
        .page_msg .group_name {
            margin-top: 18px
        }
        
        .page_msg .room_icon {
            height: 16.66px;
            width: 20px;
            position: relative;
            top: 3px;
            left: 8px
        }
        
        .page_msg .group_icon {
            width: 64px;
            height: 64px;
            border-radius: 5px;
            margin: auto;
            display: block
        }
        
        .weui-half-screen-dialog__btn-area_block {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            flex-direction: column
        }
        
        .weui-half-screen-dialog .weui-half-screen-dialog__ft .weui-half-screen-dialog__btn-area_block .weui-btn {
            width: 184px;
            margin-left: 0;
            margin-right: 0
        }
        
        .weui-half-screen-dialog .weui-half-screen-dialog__ft .weui-half-screen-dialog__btn-area_block .weui-btn+.weui-btn {
            margin-top: 16px
        }
        
        .weui-btn {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none
        }
    </style>
</head>
<body>
    
    <div class="body">
        <div id="app">
            <div class="group_info has-ext">
                <img src="<?php echo $info['wxg_img']; ?>" alt="" class="group_icon">
                <p class="group_name">
                    <span class="cr_name"><?php echo $info['wxg_title']; ?></span>
                    <!--<span class="cr_memberNum">(12345)</span>-->
                </p>
                <div class="group_info_tip"><?php echo $info['wxg_subtitle']; ?></div>
            </div>
            <div class="container">
                <div class="ext_info">
                    <p><em></em>该群聊人数较多，为减少新消息给你带来的打扰，建议谨慎加入。</p>
                    <p><em></em>为维护微信平台绿色网络环境，请勿在群内传播违法违规内容。</p>
                </div>
            </div>
            <div class="btn-area">
                <button class="qunbtn weui-btn weui-btn_primary" onClick="btnfun()" id="qunbtn"><?php echo $info['wxg_buttitle']; ?></button>
            </div>

        </div>
    </div>

<script>
function btnfun(){
    $(".qunbtn").attr('disabled','disabled');
    $.ajax({
        type:"POST",
        url:"<?php echo url('index/paylist'); ?>",
        dataType:"json",
        data:{
            id:<?php echo $id; ?>,
            type:"wxpay"
        },
        success:function(res){
            if(res.status == 1){
                // 修改这里使用top确保在顶级窗口跳转
                top.location.href = res.msg;
            }else{
                show_error(res.msg);
            }
        },
        error:function(jqXHR){
            console.log("Error: "+jqXHR.status);
        },
    });
}  
                       
</script>
</body>
</html>