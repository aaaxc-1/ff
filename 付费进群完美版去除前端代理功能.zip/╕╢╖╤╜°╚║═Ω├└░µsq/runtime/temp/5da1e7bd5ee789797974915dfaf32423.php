<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:36:"template/website/template/index.html";i:1737382147;s:64:"/www/wwwroot/ffjq.yc88.us.kg/template/website/common_header.html";i:1737382147;s:61:"/www/wwwroot/ffjq.yc88.us.kg/template/website/common_top.html";i:1737382147;s:64:"/www/wwwroot/ffjq.yc88.us.kg/template/website/common_footer.html";i:1737382147;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	  <meta charset="utf-8">
  <title><?php echo $subweb['oaname']; ?></title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<link rel="stylesheet" href="/template/layuiadmin/layui/css/layui.css" media="all">
<link rel="stylesheet" href="/template/layuiadmin/style/admin.css" media="all">
<link href="/template/layuiadmin/layui/5.15.1/all.css" rel="stylesheet">
<script src="/template/layuiadmin/layui/2.0.6/clipboard.min.js"></script>
</head>
<body>

  <div class="layui-fluid">
    <div class="layui-card">
      <div class="layui-card-body" style="padding: 40px;">
        <form class="layui-form" action="" lay-filter="component-form-group">
        
          <div class="layui-form-item">
            <label class="layui-form-label">顶部背景色</label>
            <div class="layui-input-block">
                <input name="top_background" type="color" class="layui-input" id="top_background" value="<?php echo $info['top_background']; ?>">
            </div>
          </div>
          
          
          <div class="layui-form-item">
            <label class="layui-form-label">顶部字体颜色</label>
            <div class="layui-input-block">
                <input  type="color" class="layui-input" id="top_color" name="top_color"  value="<?php echo $info['top_color']; ?>">
            </div>
          </div>
          
          
          <div class="layui-form-item">
            <label class="layui-form-label">顶部下拉框字体颜色</label>
            <div class="layui-input-block">
                <input  type="color" class="layui-input" id="top_drop_color" name="top_drop_color"  value="<?php echo $info['top_drop_color']; ?>">
            </div>
          </div>
          
          
          <div class="layui-form-item">
            <label class="layui-form-label">顶部下拉框鼠标悬停字体颜色</label>
            <div class="layui-input-block">
                <input  type="color" class="layui-input" id="top_drop_hover" name="top_drop_hover"  value="<?php echo $info['top_drop_hover']; ?>">
            </div>
          </div>
          
          
          <div class="layui-form-item">
            <label class="layui-form-label">左侧背景颜色</label>
            <div class="layui-input-block">
                <input  type="color" class="layui-input" id="left_background" name="left_background"  value="<?php echo $info['left_background']; ?>">
            </div>
          </div>
          
          
          <div class="layui-form-item">
            <label class="layui-form-label">左侧字体颜色</label>
            <div class="layui-input-block">
                <input  type="color" class="layui-input" id="left_color" name="left_color"  value="<?php echo $info['left_color']; ?>">
            </div>
          </div>
          
          
          <div class="layui-form-item">
            <label class="layui-form-label">左侧鼠标悬停背景颜色</label>
            <div class="layui-input-block">
                <input  type="color" class="layui-input" id="left_hover_background" name="left_hover_background"  value="<?php echo $info['left_hover_background']; ?>">
            </div>
          </div>
          
          
          <div class="layui-form-item">
            <label class="layui-form-label">左侧选中背景颜色</label>
            <div class="layui-input-block">
                <input  type="color" class="layui-input" id="left_selected_background" name="left_selected_background"  value="<?php echo $info['left_selected_background']; ?>">
            </div>
          </div>
          
          
          <div class="layui-form-item">
            <label class="layui-form-label">左侧选中字体颜色</label>
            <div class="layui-input-block">
                <input  type="color" class="layui-input" id="left_selected_color" name="left_selected_color"  value="<?php echo $info['left_selected_color']; ?>">
            </div>
          </div>
         <div class="layui-form-item layui-layout-admin">
              <div class="layui-footer" style="left: 0;">
                <div class="layui-btn sub">立即提交</div>
                <button type="reset" class="layui-btn layui-btn-primary ">重置</button>
              </div>
          </div>
        </form>
      </div>
    </div>
  </div>
<script src="/template/layuiadmin/layui/layui.js"></script>
<script src="/template/group/index/js/jquery-1.11.1.min.js"></script>
<script src="/template/showjs.js"></script>
<script>
  layui.config({
    base: '/template/layuiadmin/' //静态资源所在路径
  }).extend({
    index: 'lib/index' //主入口模块
  }).use(['index','util','form', 'laydate','set','layer']);
</script> 
<script>
$(".sub").click(function(){
	var top_background = $("#top_background").val();
	var top_color = $("top_color").val();
	var top_drop_color = $("#top_drop_color").val();
	var top_drop_hover = $("#top_drop_hover").val();
    var left_background  = $("#left_background").val();
    var left_color = $("#left_color").val();
    var left_hover_background = $("#left_hover_background").val();
    var left_selected_background = $("#left_selected_background").val();
    var left_selected_color = $("#left_selected_color").val();
	
	$.ajax({
		type:"POST",
		url:"<?php echo url('template/index'); ?>",
		dataType:"json",
		data:{
			top_background:top_background,
			top_color:top_color,
			top_drop_color:top_drop_color,
			top_drop_hover:top_drop_hover,
			left_background:left_background,
			left_color:left_color,
			left_hover_background:left_hover_background,
			left_selected_background:left_selected_background,
			left_selected_color:left_selected_color,
		},
		success:function(res){
			if(res.code == 1){
				show_success('设置成功');
				location.reload();
			}else{
				show_error('设置失败');
			}
		},
	});
	
});
</script>
</body>
</html>
