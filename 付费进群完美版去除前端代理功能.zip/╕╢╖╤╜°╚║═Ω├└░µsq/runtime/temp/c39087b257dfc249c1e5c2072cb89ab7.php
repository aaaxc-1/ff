<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:37:"template/substation/fanghong/add.html";i:1737382147;s:67:"/www/wwwroot/ffjq.yc88.us.kg/template/substation/common_header.html";i:1737382147;s:64:"/www/wwwroot/ffjq.yc88.us.kg/template/substation/common_top.html";i:1737382147;s:67:"/www/wwwroot/ffjq.yc88.us.kg/template/substation/common_footer.html";i:1737382147;}*/ ?>
<!DOCTYPE html>
<html>
<head>
      <meta charset="utf-8">
  <title><?php echo session("su_title"); ?> <?php echo $subweb['oaname']; ?></title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/template/layuiadmin/layui/css/layui.css" media="all">
<link rel="stylesheet" href="/template/layuiadmin/style/admin.css" media="all">
<link href="/template/layuiadmin/layui/5.15.1/all.css" rel="stylesheet">
<script src="/template/layuiadmin/layui/2.0.6/clipboard.min.js"></script>
</head>
<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-card-body" style="padding: 15px;">
            <form class="layui-form" action="" lay-filter="component-form-group">
                <div class="layui-form-item">
                    <label class="layui-form-label">域名</label>
                    <div class="layui-input-block">
                        <input name="domain" type="text" class="layui-input" id="domain" placeholder="请输入域名">
                        <div class="layui-form-mid layui-word-aux">注意: 不要输入http://或https://</div>
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">状态</label>
                    <div class="layui-input-block">
                        <input type="radio" name="status" value="1" title="启用" checked="">
                        <input type="radio" name="status" value="2" title="禁用">
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">备注</label>
                    <div class="layui-input-block">
                        <textarea name="remark" class="layui-textarea" id="remark" placeholder="请输入备注"></textarea>
                    </div>
                </div>

                <div class="layui-form-item layui-layout-admin">
                    <div class="layui-footer" style="left: 0;">
                        <div class="layui-btn sub">立即提交</div>
                        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="/template/layuiadmin/layui/layui.js"></script>
<script src="/template/group/index/js/jquery-1.11.1.min.js"></script>
<script src="/template/showjs.js"></script>
<script>
  layui.config({
    base: '/template/layuiadmin/' //静态资源所在路径
  }).extend({
    index: 'lib/index' //主入口模块
  }).use(['index','util','form', 'laydate','set','layer']);
</script>
<script>
layui.use(['form'], function(){
    var form = layui.form;
});

$(".sub").click(function(){
    var domain = $("#domain").val();
    var status = $("input[name='status']:checked").val();
    var remark = $("#remark").val();

    if(domain == ""){
        show_error("域名不能为空!");
        return false;
    }

    $.ajax({
        type: "POST",
        url: "<?php echo url('fanghong/add'); ?>",
        dataType: "json",
        data: {
            domain: domain,
            status: status,
            remark: remark
        },
        success: function(res){
            if(res.code == 1){
                window.parent.layer.closeAll(); //关闭弹窗
                window.parent.location.reload();
            }else{
                show_error(res.msg);
            }
        },
        error: function(jqXHR){
            console.log("Error: "+jqXHR.status);
        }
    });
});
</script>
</body>
</html>