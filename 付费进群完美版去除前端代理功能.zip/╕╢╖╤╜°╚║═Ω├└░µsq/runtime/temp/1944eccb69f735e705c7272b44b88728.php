<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:34:"template/fenxiao/wxgroup/turl.html";i:1736945106;s:64:"/www/wwwroot/ffjq.yc88.us.kg/template/fenxiao/common_header.html";i:1734445844;s:61:"/www/wwwroot/ffjq.yc88.us.kg/template/fenxiao/common_top.html";i:1734445844;}*/ ?>
<!DOCTYPE html>
<html>
<head>
      <meta charset="utf-8">
  <title><?php echo session("du_name"); ?> <?php echo $subweb['oaname']; ?></title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/template/layuiadmin/layui/css/layui.css" media="all">
<link rel="stylesheet" href="/template/layuiadmin/style/admin.css" media="all">
<link href="/template/layuiadmin/layui/5.15.1/all.css" rel="stylesheet">
<script src="/template/layuiadmin/layui/2.0.6/clipboard.min.js"></script>
</head>
<body>
<div style="padding: 15px;">
    <div>原始链接：<a href="<?php echo $url; ?>" target="_blank"><?php echo $url; ?></a></div>
    
    <div style="margin: 10px 0;">
        <select id="domain-select" class="layui-select">
            <option value="">请选择防红域名</option>
            <?php foreach($domains as $domain): ?>
            <option value="<?php echo $domain['domain']; ?>"><?php echo $domain['domain']; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    
    <div id="final-url" style="margin: 10px 0;"></div>
    
    <div id="qrcode">
        <img width="355" height="355" src="/qrcode.php?size=200x200&data=<?php echo $url; ?>">
    </div>
</div>

<script>
layui.use(['form'], function(){
    var $ = layui.$;
    
    // 监听域名选择
    $('#domain-select').on('change', function(){
        var domain = $(this).val();
        var originalUrl = '<?php echo $url; ?>';
        
        if(domain) {
            // 生成base64编码的原始链接
            var base64Url = btoa(encodeURIComponent(originalUrl));
            var finalUrl = 'http://' + domain + '?c=' + base64Url;
            
            // 显示最终链接
            $('#final-url').html('最终链接：<a href="' + finalUrl + '" target="_blank">' + finalUrl + '</a>');
            
            // 更新二维码
            $('#qrcode').html('<img width="355" height="355" src="/qrcode.php?size=200x200&data=' + encodeURIComponent(finalUrl) + '">');
        } else {
            // 如果未选择域名，显示原始链接
            $('#final-url').html('');
            $('#qrcode').html('<img width="355" height="355" src="/qrcode.php?size=200x200&data=' + encodeURIComponent(originalUrl) + '">');
        }
    });
});
</script>
</body>
</html>