<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:35:"template/substation/data/index.html";i:1737382147;s:67:"/www/wwwroot/ffjq.yc88.us.kg/template/substation/common_header.html";i:1737382147;s:64:"/www/wwwroot/ffjq.yc88.us.kg/template/substation/common_top.html";i:1737382147;}*/ ?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>付费进群系统数据可视化大屏</title>
    <script type="text/javascript" src="/template/substation/data/js/jquery.js"></script>
    <link rel="stylesheet" href="/template/substation/data/css/comon0.css">
      <meta charset="utf-8">
  <title><?php echo session("su_title"); ?> <?php echo $subweb['oaname']; ?></title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/template/layuiadmin/layui/css/layui.css" media="all">
<link rel="stylesheet" href="/template/layuiadmin/style/admin.css" media="all">
<link href="/template/layuiadmin/layui/5.15.1/all.css" rel="stylesheet">
<script src="/template/layuiadmin/layui/2.0.6/clipboard.min.js"></script>
</head>
<body>
<div class="loading">
    <div class="loadbox"><img src="/template/substation/data/images/loading.gif"> 页面加载中...</div>
</div>
<div class="head">
    <h1>雨辰付费进群系统数据中心</h1>
    <div class="time" id="showTime"><?php echo date('Y/m/d H:i:s') ?></div>
    <script>
        var t = null;

        // t = setTimeout(time, 1000);//開始运行
        function time() {
            clearTimeout(t);//清除定时器
            dt = new Date();
            var y = dt.getFullYear();
            var mt = dt.getMonth() + 1;
            var day = dt.getDate();
            var h = dt.getHours();//获取时
            var m = dt.getMinutes();//获取分
            var s = dt.getSeconds();//获取秒
            var t = null;
            document.getElementById("showTime").innerHTML = y + "/" + Appendzero(mt) + "/" + Appendzero(day) + " " + Appendzero(h) + ":" + Appendzero(m) + ":" + Appendzero(s) + "";

            function Appendzero(obj) {
                if (obj < 10) return "0" + "" + obj;
                else return obj;
            }

            t = setTimeout(time, 1000); //设定定时器，循环运行
        }

    </script>

</div>
<div class="mainbox">
    <ul class="clearfix">
        <li>
            <div class="boxall" style="height: calc(40% - .15rem)">
                <div class="alltitle">销售数据统计</div>
                <div class="sycm">
                    <ul class="clearfix">
                        <li>
                            <h2><?php echo round($d_money_count,2); ?></h2>
                            <span>今日销售额</span></li>
                        <li>
                            <h2><?php echo $d_bill_count; ?></h2>
                            <span>今日订单量</span></li>
                        <li>
                            <h2><?php echo $d_user_count; ?></h2>
                            <span>今日新增用户</span></li>

                        <li>
                            <h2><?php echo round($dtxmoney,2); ?></h2>
                            <span>待处理提现金额</span></li>

                    </ul>
                </div>
                <div class="boxfoot"></div>
            </div>
            <div class="boxall" style="height: calc(60% - .15rem)">
                <div class="alltitle">销售数据统计</div>
                <div class="sycm sycm2">
                    <ul class="clearfix">
                        <li>
                            <h2><?php echo round($z_money_count,2); ?></h2>
                            <span>总销售额</span></li>
                        <li>
                            <h2><?php echo $z_bill_count; ?></h2>
                            <span>总订单量</span></li>
                        <li>
                            <h2><?php echo $z_user_count; ?></h2>
                            <span>总用户数</span></li>

                        <li>
                            <h2><?php echo round($qmoney,2); ?></h2>
                            <span>纯利润</span></li>
                        <li>
                            <h2><?php echo round($fswtsmoney,2); ?></h2>
                            <span>分销未提金额</span></li>

                        <li>
                            <h2><?php echo round($dtxmoney,2); ?></h2>
                            <span>待处理提现金额</span></li>

                    </ul>
                </div>
                <div class="boxfoot"></div>
            </div>

        </li>
        <li>
            <div style="position: relative">
                <div class="barnav">

                    <div class="bar">
                        <div class="barbox">
                            <ul class="clearfix">
                                <li class="pulll_left counter"><?php echo round($d_money_count,2); ?></li>
                                <li class="pulll_left counter"><?php echo round($z_money_count,2); ?></li>
                                <li class="pulll_left counter"><?php echo $z_bill_count; ?></li>
                            </ul>
                        </div>
                        <div class="barbox2">
                            <ul class="clearfix">
                                <li class="pulll_left">今日销售额</li>
                                <li class="pulll_left">总销售额</li>
                                <li class="pulll_left">总订单量</li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
            <div class="mapbox">
                <div class="map">
                    <div class="map1"><img src="/template/substation/data/images/lbx.png"></div>
                    <div class="map2"><img src="/template/substation/data/images/jt.png"></div>
                    <div class="map3"><img src="/template/substation/data/images/map.png"></div>
                    <div class="map4" id="map_1"></div>
                </div>
            </div>
        </li>
        <li>
            <div class="boxall" style="height: calc(50% - .15rem)">
                <div class="diytitle">
                    <ul>
                        <li>
                            <p>
                                <span>所属分销</span>
                                <span>群名称</span>
                                <span>订单数</span>
                            </p>
                        </li>
                    </ul>
                </div>
                <div class="wrap boxnav">
                    <ul>
                        <?php if(is_array($wxgroup) || $wxgroup instanceof \think\Collection || $wxgroup instanceof \think\Paginator): $i = 0; $__LIST__ = $wxgroup;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <li>
                            <p>
                                <span><?php echo $vo['du_name']; ?></span>
                                <span><?php echo $vo['wxg_title']; ?></span>
                                <span><?php echo $vo['count_ddx']; ?></span>
                            </p>
                        </li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>

                    </ul>
                </div>
                <div class="boxfoot"></div>
            </div>
            <div class="boxall" style="height: calc(50% - .15rem)">
                <!--                <div class="alltitle">实时账单</div>-->
                <div class="diytitle">
                    <ul>
                        <li>
                            <p>
                                <span>所属分销</span>
                                <span style="width:auto;">状态</span>
                                <span>金额</span>
                            </p>
                        </li>
                    </ul>
                </div>

                <div class="wrap boxnav">
                    <ul>
                        <?php if(is_array($bill_data) || $bill_data instanceof \think\Collection || $bill_data instanceof \think\Paginator): $i = 0; $__LIST__ = $bill_data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <li>
                            <p>
                                <span><?php echo $vo['du_smname']; ?></span>
                                <span><?php if($vo['bl_status']==1): ?>待支付
                        <?php elseif($vo['bl_status']==2): ?>支付完成
                        <?php elseif($vo['dt_status']==4): ?>支付失败<?php endif; ?></span>
                                <span><?php echo $vo['bl_money']; ?>元</span>
                            </p>
                        </li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>

                    </ul>
                </div>
                <div class="boxfoot"></div>
            </div>
        </li>
    </ul>
    <div class="copyright">付费进群系统5.2版</div>
</div>

<div class="mainbox2">
    <ul class="clearfix">
        <li>

            <div class="boxall" style="height: 100%">
                <div class="alltitle">数据分析
                    <div class="pulll_right">
                        <a href="#"><span></span>已完成</a>
                        <a href="#"><span></span>未完成</a>
                    </div>
                </div>
                <div class="boxnav">
                    <ul class="btbox">
                        <li id="bt01"></li>
                        <li id="bt02"></li>
                        <li id="bt03"></li>
                        <li id="bt04"></li>
                    </ul>
                </div>
                <div class="boxfoot"></div>
            </div>

        </li>
        <li>
            <div class="boxall" style="height:100%">
                <div class="alltitle">折线统计图
                    <div class="pulll_right sebtn">
<!--                        <a href="#" class="active">近七天</a>-->
<!--                        <a href="#">近30天</a>-->
<!--                        <a href="#">12月</a>-->
                    </div>
                </div>
                <div class="boxnav" id="echart4"></div>


                <div class="boxfoot"></div>
            </div>
        </li>

    </ul>
</div>
<script>
    // 数据分析
    let btData = [
        {
            'data1': "<?php echo $analysis[0]['count_ddx']; ?>",
            'data2': "<?php echo $analysis[0]['wxg_readcount']; ?>",
            'data3': "<?php echo $analysis[0]['du_smname']; ?>"
        },
        {
            'data1': "<?php echo $analysis[1]['count_ddx']; ?>",
            'data2': "<?php echo $analysis[1]['wxg_readcount']; ?>",
            'data3': "<?php echo $analysis[1]['du_smname']; ?>"
        },
        {
            'data1': "<?php echo $analysis[2]['count_ddx']; ?>",
            'data2': "<?php echo $analysis[2]['wxg_readcount']; ?>",
            'data3': "<?php echo $analysis[2]['du_smname']; ?>"
        },
        {
            'data1': "<?php echo $analysis[3]['count_ddx']; ?>",
            'data2': "<?php echo $analysis[3]['wxg_readcount']; ?>",
            'data3': "<?php echo $analysis[3]['du_smname']; ?>"
        }
    ];

    // 折线图数据
    let dates = ["<?php echo $dates[0]; ?>","<?php echo $dates[1]; ?>","<?php echo $dates[2]; ?>","<?php echo $dates[3]; ?>","<?php echo $dates[4]; ?>","<?php echo $dates[5]; ?>","<?php echo $dates[6]; ?>"];
    let orderNums = [<?php echo $order_nums[0]; ?>,<?php echo $order_nums[1]; ?>,<?php echo $order_nums[2]; ?>,<?php echo $order_nums[3]; ?>,<?php echo $order_nums[4]; ?>,<?php echo $order_nums[5]; ?>,<?php echo $order_nums[6]; ?>];
    let orderAmounts = [<?php echo $order_amounts[0]; ?>,<?php echo $order_amounts[1]; ?>,<?php echo $order_amounts[2]; ?>,<?php echo $order_amounts[3]; ?>,<?php echo $order_amounts[4]; ?>,<?php echo $order_amounts[5]; ?>,<?php echo $order_amounts[6]; ?>];

</script>
<script language="JavaScript" src="/template/substation/data/js/js.js"></script>
<script type="text/javascript" src="/template/substation/data/js/echarts.min.js"></script>
<script type="text/javascript" src="/template/substation/data/js/china.js"></script>
<script type="text/javascript" src="/template/substation/data/js/area_echarts.js"></script>
<script src="/template/substation/data/js/jquery.liMarquee.js"></script>
<script>
    $(function () {
        $('.wrap,.adduser').liMarquee({
            direction: 'up',//身上滚动
            runshort: false,//内容不足时不滚动
            scrollamount: 20//速度
        });
    });

</script>
<!--<meta http-equiv="refresh" content="5;url='#'">-->

<script type="text/javascript">
    $('.counter').countUp();
</script>
</body>
</html>
