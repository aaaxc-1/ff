<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:37:"template/substation/huitiao/edit.html";i:1739130314;s:67:"/www/wwwroot/ffjq.yc88.us.kg/template/substation/common_header.html";i:1737382147;s:64:"/www/wwwroot/ffjq.yc88.us.kg/template/substation/common_top.html";i:1737382147;}*/ ?>
<!DOCTYPE html>
<html>
<head>
      <meta charset="utf-8">
  <title><?php echo session("su_title"); ?> <?php echo $subweb['oaname']; ?></title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/template/layuiadmin/layui/css/layui.css" media="all">
<link rel="stylesheet" href="/template/layuiadmin/style/admin.css" media="all">
<link href="/template/layuiadmin/layui/5.15.1/all.css" rel="stylesheet">
<script src="/template/layuiadmin/layui/2.0.6/clipboard.min.js"></script>
</head>
<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-card-body" style="padding: 15px;">
            <form class="layui-form" action="" lay-filter="component-form-group">
                <input type="hidden" name="id" value="<?php echo $info['id']; ?>">
                
                <div class="layui-form-item">
                    <label class="layui-form-label">域名</label>
                    <div class="layui-input-block">
                        <input name="domain" type="text" class="layui-input" value="<?php echo $info['domain']; ?>" placeholder="请输入回调域名">
                        <div class="layui-form-mid layui-word-aux">注意: 不要输入http://或https://</div>
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">支付类型</label>
                    <div class="layui-input-block">
                        <input type="radio" name="type" value="1" title="易支付" <?php if($info['type']==1): ?>checked<?php endif; ?>>
                        <input type="radio" name="type" value="2" title="码支付" <?php if($info['type']==2): ?>checked<?php endif; ?>>
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">状态</label>
                    <div class="layui-input-block">
                        <input type="radio" name="status" value="1" title="启用" <?php if($info['status']==1): ?>checked<?php endif; ?>>
                        <input type="radio" name="status" value="2" title="禁用" <?php if($info['status']==2): ?>checked<?php endif; ?>>
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">备注</label>
                    <div class="layui-input-block">
                        <textarea name="remark" class="layui-textarea" placeholder="请输入备注"><?php echo $info['remark']; ?></textarea>
                    </div>
                </div>

                <div class="layui-form-item layui-layout-admin">
                    <div class="layui-footer" style="left: 0;">
                        <div class="layui-btn sub">立即提交</div>
                        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
layui.use(['form'], function(){
    var form = layui.form;
    
    $('.sub').click(function(){
        $.post('<?php echo url("huitiao/edit"); ?>', $('form').serialize(), function(res){
            if(res.code == 1){
                parent.layer.msg(res.msg, {icon: 1});
                parent.location.reload();
                var index = parent.layer.getFrameIndex(window.name);
                parent.layer.close(index);
            }else{
                layer.msg(res.msg, {icon: 2});
            }
        }, 'json');
    });
});
</script>
</body>
</html>
