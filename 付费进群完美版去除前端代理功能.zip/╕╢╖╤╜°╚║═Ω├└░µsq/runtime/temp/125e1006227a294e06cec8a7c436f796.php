<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:35:"template/fenxiao/wxgroup/index.html";i:1737382147;s:64:"/www/wwwroot/ffjq.yc88.us.kg/template/fenxiao/common_header.html";i:1737382147;s:61:"/www/wwwroot/ffjq.yc88.us.kg/template/fenxiao/common_top.html";i:1737382147;s:64:"/www/wwwroot/ffjq.yc88.us.kg/template/fenxiao/common_footer.html";i:1737382147;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	  <meta charset="utf-8">
  <title><?php echo session("du_name"); ?> <?php echo $subweb['oaname']; ?></title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<link rel="stylesheet" href="/template/layuiadmin/layui/css/layui.css" media="all">
<link rel="stylesheet" href="/template/layuiadmin/style/admin.css" media="all">
<link href="/template/layuiadmin/layui/5.15.1/all.css" rel="stylesheet">
<script src="/template/layuiadmin/layui/2.0.6/clipboard.min.js"></script>
</head>
<body>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
      <div class="layui-col-md12">
        <div class="layui-card">
          <div class="layui-card-body">
          	<div class="layui-box">
          	    <?php if($d_info['du_tmp']==1): ?>
			<button class="layui-btn layuiadmin-btn-tags" data-type="add">添加多图群组</button>
			<button class="layui-btn layuiadmin-btn-tags" data-type="addimg">添加单图群组</button>
			<button class="layui-btn layuiadmin-btn-tags" data-type="addgmb">添加官方群组</button>
			<?php endif; if(!empty($webinfo['text11'])): ?><a class="layui-btn layuiadmin-btn-tags" href="<?php echo $webinfo['text11']; ?>" target="_blank">功能说明</a><?php endif; ?>
			 </div>
			<div class="layui-form" lay-filter="component-form-element">
            <div class="layui-box layui-laypage layui-laypage-molv"><?php echo $page; ?></div>
            <table class="layui-table" lay-even="" lay-skin="nob">
            <thead>
              <tr>
                <th width="35">序号</th>
                <th>状态</th>
                <th>群名称</th>
                <th>订单数</th>
                <th>曝光量</th>
                <th>转化率</th>
                <th>入群金额</th>
                <th>总收款</th>
                <th>总赢利</th>
                <th>备注</th>
                <th width="130">管理</th>
              </tr> 
            </thead>
            <tbody>
             <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<tr id="tr_<?php echo $vo['wxg_id']; ?>">
					<td class="text-center"><?php echo $vo['wxg_id']; ?></td>
                    <td>
                    <?php if($vo['wxg_status']==1): ?><span class="layui-badge layui-bg-blue">启用</span>
                    <?php elseif($vo['wxg_status']==2): ?><span class="layui-badge layui-bg-black">禁用</span><?php endif; ?>
                    </td>
                    <td><span class="layui-badge-rim"><?php echo $vo['wxg_title']; ?></span></td>
                    <td><?php echo $vo['count_ddx']; ?></td>
                    <td><?php echo $vo['wxg_readcount']; ?> 次</td>
                    <td><?php echo round($vo['count_ddx']/ $vo['wxg_readcount'] * 100,2); ?>%</td>
                    <td><?php echo $vo['wxg_money']; ?> 元</td>
                    <td><?php echo round($vo['count_z_money'],2); ?> 元</td>
                    <td><?php echo round($vo['count_p_money'],2); ?> 元</td>
                    <td><?php echo $vo['wxg_content']; ?></td>
                    <td>
							<div class="layui-btn-group">
								<button class="layui-btn layui-btn-sm" onClick="calldel('<?php echo url('wxgroup/del',array('id'=>$vo['wxg_id'])); ?>','tr_<?php echo $vo['wxg_id']; ?>')"><i class="layui-icon">&#xe640;</i></button>
								<?php if($d_info['du_tmp']==1): if($vo['wxg_type']==1): ?>
                                <button class="layui-btn layui-btn-sm" data-type="edit" data-id="<?php echo $vo['wxg_id']; ?>"><i class="layui-icon">&#xe642;</i></button>
                                <?php elseif($vo['wxg_type']==2): ?>
                                <button class="layui-btn layui-btn-sm" data-type="editimg" data-id="<?php echo $vo['wxg_id']; ?>"><i class="layui-icon">&#xe642;</i></button>
                                <?php elseif($vo['wxg_type']==3): ?>
                                <button class="layui-btn layui-btn-sm" data-type="editgmb" data-id="<?php echo $vo['wxg_id']; ?>"><i class="layui-icon">&#xe642;</i></button>
                                <?php endif; endif; ?>
                                <button class="layui-btn layui-btn-sm" data-type="turl" data-id="<?php echo $vo['wxg_id']; ?>">提链</button>
							</div>
                    </td>
				</tr>
			<?php endforeach; endif; else: echo "" ;endif; ?>
            </tbody>
          </table> 
          <div class="layui-box layui-laypage layui-laypage-molv"><?php echo $page; ?></div>
		  </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="/template/layuiadmin/layui/layui.js"></script>
<script src="/template/group/index/js/jquery-1.11.1.min.js"></script>
<script src="/template/showjs.js"></script>
<script>
  layui.config({
    base: '/template/layuiadmin/' //静态资源所在路径
  }).extend({
    index: 'lib/index' //主入口模块
  }).use(['index','util','form', 'laydate','set','layer']);
</script> 
   <script>
	layui.use(['index','form'], function(){
		
		var form = layui.form;
		
    var $ = layui.$, active = {

	  add: function(){
        layer.open({
          type: 2
          ,title: '添加群组'
          ,content: '<?php echo url('wxgroup/add'); ?>'
          ,area: ['800px', '750px']
        }); 
      },
      
	  addimg: function(){
        layer.open({
          type: 2
          ,title: '添加单图群组'
          ,content: '<?php echo url('wxgroup/addimg'); ?>'
          ,area: ['800px', '750px']
        }); 
      },
      
	  addgmb: function(){
        layer.open({
          type: 2
          ,title: '添加官模板群组'
          ,content: '<?php echo url('wxgroup/addgmb'); ?>'
          ,area: ['800px', '750px']
        }); 
      },
      
	  edit: function(){
		var id = $(this).data('id');
		var url = '<?php echo url('wxgroup/edit',array('id'=>'AAAAAA')); ?>';
		url = url.replace("AAAAAA",id)
        layer.open({
          type: 2
          ,title: '修改群组'
          ,content: url
          ,area: ['800px', '750px']
        }); 
      },
      
	  editimg: function(){
		var id = $(this).data('id');
		var url = '<?php echo url('wxgroup/editimg',array('id'=>'AAAAAA')); ?>';
		url = url.replace("AAAAAA",id)
        layer.open({
          type: 2
          ,title: '修改单图群组'
          ,content: url
          ,area: ['800px', '750px']
        }); 
      },
      
	  editgmb: function(){
		var id = $(this).data('id');
		var url = '<?php echo url('wxgroup/editgmb',array('id'=>'AAAAAA')); ?>';
		url = url.replace("AAAAAA",id)
        layer.open({
          type: 2
          ,title: '修改官模板群组'
          ,content: url
          ,area: ['800px', '750px']
        }); 
      },
      
turl: function(){
    var id = $(this).data('id');
    var url1 = "http://<?php echo $safe_url; ?>/safe/index?id=" + id;
    var qrUrl = "/qrcode.php?size=290x290&data="+url1;
    
    layer.open({
        type: 1,
        title: '提链',
        content: '<div style="padding: 15px;">' +
            '<div style="margin-bottom: 10px;">' +
                '<div style="font-weight: bold; margin-bottom: 5px;">原始链接:</div>' +
                '<div style="word-break: break-all;">' +
                    '<a href="'+url1+'" target="_blank" style="color: #1E9FFF;">'+url1+'</a>' +
                '</div>' +
            '</div>' +
            '<div id="domain-select-container"></div>' +
            '<div id="final-url" style="margin: 10px 0;"></div>' +
            '<div style="text-align: center; margin: 10px 0;">' +
                '<img src="'+qrUrl+'" alt="QR Code" style="width: 290px; height: 290px;"><br>' +
            '</div>' +
            '<div style="text-align: center; padding: 20px 0;">' +
                '<button id="copyBtn" class="layui-btn layui-btn-normal layui-btn" data-clipboard-text="'+url1+'">复制链接</button>' +
            '</div>' +
            '</div>',
        area: ['650px', '650px'],
        success: function(layero, index){
            // 初始化复制功能
            var clipboard = new ClipboardJS('#copyBtn');
            clipboard.on('success', function(e) {
                layer.msg('复制成功');
                e.clearSelection();
            });
            clipboard.on('error', function() {
                layer.msg('复制失败，请手动复制');
            });

            $.get("<?php echo url('wxgroup/getDomains'); ?>", function(res){
                if(res.code == 1 && res.data.length > 0) {
                    var domainSelect = '<div style="margin-bottom: 10px;">' +
                        '<div style="font-weight: bold; margin-bottom: 5px;">选择防红域名:</div>' +
                        '<select id="domain-select" class="layui-select" style="width:100%;">' +
                        '<option value="">请选择防红域名</option>';
                    res.data.forEach(function(domain) {
                        domainSelect += '<option value="' + domain.domain + '">' + domain.domain + '</option>';
                    });
                    domainSelect += '</select></div>';
                    $('#domain-select-container').html(domainSelect);
                    
                    $('#domain-select').on('change', function(){
                        var domain = $(this).val();
                        if(domain) {
                            var base64Url = btoa(url1);
                            var finalUrl = 'http://' + domain + '?c=' + base64Url;
                            $('#final-url').html(
                                '<div style="font-weight: bold; margin-bottom: 5px;">最终链接:</div>' +
                                '<div style="word-break: break-all;">' +
                                    '<a href="'+finalUrl+'" target="_blank" style="color: #1E9FFF;">'+finalUrl+'</a>' +
                                '</div>'
                            );
                            $('#copyBtn').attr('data-clipboard-text', finalUrl);
                            $(layero).find('img').attr('src', "/qrcode.php?size=290x290&data="+encodeURIComponent(finalUrl));
                        } else {
                            $('#final-url').html('');
                            $('#copyBtn').attr('data-clipboard-text', url1);
                            $(layero).find('img').attr('src', qrUrl);
                        }
                    });
                }
            });
        }
    }); 
}
    };

    $('.layui-btn').on('click', function(){
      var type = $(this).data('type');
      active[type] ? active[type].call(this) : '';
    });

  });
  </script>
  <!-- 引入 Clipboard.js -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.6/clipboard.min.js"></script>
</body>
</html>
