<?php
/*
 本代码由 DeckPHP Beta [ V2.0.5 ] 创建
 创建时间 2025-02-19 23:31:07
 技术支持 闲鱼：俗人云创网络
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/
if(!defined('A___A_A_A'))define('A___A_A_A', '_A__A_A__');$GLOBALS[A___A_A_A]=explode('|0|P|P','H*|0|P|PE4BDA0E79A84E68E88E69D83E5AF86E992A5');unset($��������);$��������; $authcode=pack($GLOBALS[A___A_A_A][15-5+7-17],$GLOBALS[A___A_A_A][1]);
?>