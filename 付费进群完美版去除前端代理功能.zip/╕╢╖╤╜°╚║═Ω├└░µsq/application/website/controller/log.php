array (
  0 => 'center/index',
  1 => 
  array (
    1 => 'users/logs',
    2 => 'users/password',
    3 => 'website/getsizeurl',
    4 => 'template/index',
    5 => 'mail/index',
  ),
)