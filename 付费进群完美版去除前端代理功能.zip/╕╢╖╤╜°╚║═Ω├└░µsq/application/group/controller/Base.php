<?php
namespace app\group\controller;
use think\Controller;
use think\Db;
use think\Session;
use think\Request;
use think\Config;
class Base extends Controller{
	
	
	public function _initialize(){

	}

	
}
