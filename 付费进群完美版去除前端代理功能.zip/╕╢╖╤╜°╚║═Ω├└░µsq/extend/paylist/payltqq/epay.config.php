<?php
/* *
 * 配置文件
 */

//支付接口地址
$epay_config['apiurl'] = 'https://cc.songciya.cn/';

//商户ID
$epay_config['pid'] = '1000';

//商户密钥
$epay_config['key'] = '2pZF7rihPRdrHxH7r7z77F57Jioh7He7';
