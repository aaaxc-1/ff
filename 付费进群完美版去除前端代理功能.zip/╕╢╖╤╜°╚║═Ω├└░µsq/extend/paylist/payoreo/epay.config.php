<?php
/* *
 * 配置文件
 */

//支付接口地址
$epay_config['apiurl'] = '';

//商户ID
$epay_config['pid'] = '';

//商户密钥
$epay_config['key'] = '';
